package com.company.kg.geektech.lesson8.players;

public enum HavingSuperAbilities {
    CRITICAL_DAMAGE, BOOST, HEALS, SAVE_DAMAGE_AND_REVERT, CRID, DEFENCE,SPELL
}
