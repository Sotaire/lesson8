package com.company.kg.geektech.lesson8.field;

public class Main {

    public static void main(String[] args) {

        RPG_Game.startGame();

    }
}
