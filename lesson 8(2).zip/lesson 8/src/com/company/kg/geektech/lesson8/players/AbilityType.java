package com.company.kg.geektech.lesson8.players;

public interface AbilityType {

    void abilitySuperAbility(Boss boss,Hero[] heroes);

}
